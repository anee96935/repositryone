<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );
         
if ( !function_exists( 'child_theme_configurator_css' ) ):
    function child_theme_configurator_css() {
        wp_enqueue_style( 'chld_thm_cfg_child', trailingslashit( get_stylesheet_directory_uri() ) . 'style.css', array( 'hello-elementor','hello-elementor','hello-elementor-theme-style' ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'child_theme_configurator_css', 10 );

// END ENQUEUE PARENT ACTION

include 'other_function.php';

function child_enqueue_styles() {

	wp_enqueue_style( 'typekit_fonts', 'https://use.typekit.net/bza8sow.css', array( 'hello-elementor','hello-elementor','hello-elementor-theme-style' ));
	wp_enqueue_style( 'typekit_fonts_2', 'https://use.typekit.net/cls4ewk.css', array( 'hello-elementor','hello-elementor','hello-elementor-theme-style' ));
    wp_enqueue_script( 'custom-js', get_stylesheet_directory_uri() . '/js/custom.js', array ( 'jquery' ), 1.1, true);
    

    wp_localize_script( 'rsclean-request-script', 'theme_ajax', array(
	    'url'        	=> admin_url( 'admin-ajax.php' ),
	    'site_url'     	=> get_bloginfo('url'),
	    'theme_url' 	=> get_bloginfo('template_directory')
	) );
}

add_action( 'wp_enqueue_scripts', 'child_enqueue_styles', 15 );


function mytheme_register_nav_menu(){
    register_nav_menus( array(
        'footer_about_menu' => __( 'Footer About Menu', 'text_domain' ),
        'footer_product_menu'  => __( 'Footer Product Menu', 'text_domain' ),
        'footer_contact_menu'  => __( 'Footer Contact Menu', 'text_domain' ),
        'footer_resources_menu'  => __( 'Footer Resources Menu', 'text_domain' ),
    ) );
}
add_action( 'after_setup_theme', 'mytheme_register_nav_menu', 0 );

/* Add this code in function.php */
	
	
function etheme_get_resized_url($id,$width, $height, $crop) 
{
    if ( function_exists("gd_info") && (($width >= 10) && ($height >= 10)) && (($width <= 1024) && ($height <= 1024)) ) 
    {
        $vt_image = vt_resize( $id, '', $width, $height, $crop );
        if ($vt_image) 
            $image_url = $vt_image['url'];
        else
            $image_url = false;
    }
    else 
    {
        $full_image = wp_get_attachment_image_src( $id, 'full');
        if (!empty($full_image[0]))
            $image_url = $full_image[0];
        else
            $image_url = false;
    }
    if( is_ssl() && !strstr(  $image_url, 'https' ) ) str_replace('http', 'https', $image_url);
        return $image_url;
}
if ( !function_exists('vt_resize') ) 
{
    function vt_resize( $attach_id = null, $img_url = null, $width, $height, $crop = false ) 
    {
        // this is an attachment, so we have the ID
        if ( $attach_id ) 
        {
            $image_src = wp_get_attachment_image_src( $attach_id, 'full' );
            $file_path = get_attached_file( $attach_id );
            // this is not an attachment, let's use the image url
        } 
        else if ( $img_url ) 
        {
            $file_path = parse_url( $img_url );
            $file_path = $_SERVER['DOCUMENT_ROOT'] . $file_path['path'];
            //$file_path = ltrim( $file_path['path'], '/' );
            //$file_path = rtrim( ABSPATH, '/' ).$file_path['path'];
            $orig_size = getimagesize( $file_path );
            $image_src[0] = $img_url;
            $image_src[1] = $orig_size[0];
            $image_src[2] = $orig_size[1];
        }
        $file_info = pathinfo( $file_path );
        // check if file exists
        $base_file = $file_info['dirname'].'/'.$file_info['filename'].'.'.$file_info['extension'];
        if ( !file_exists($base_file) )
            return;
            $extension = '.'. $file_info['extension'];
            // the image path without the extension
            $no_ext_path = $file_info['dirname'].'/'.$file_info['filename'];
            // checking if the file size is larger than the target size
            // if it is smaller or the same size, stop right here and return
        if ( $image_src[1] > $width || $image_src[2] > $height ) 
        {
            if ( $crop == true ) 
            {
                $cropped_img_path = $no_ext_path.'-'.$width.'x'.$height.$extension;
                // the file is larger, check if the resized version already exists (for $crop = true but will also work for $crop = false if the sizes match)
                if ( file_exists( $cropped_img_path ) ) 
                {
                    $cropped_img_url = str_replace( basename( $image_src[0] ), basename( $cropped_img_path ), $image_src[0] );
                    $vt_image = array (
                    'url' => $cropped_img_url,
                    'width' => $width,
                    'height' => $height
                    );
                    return $vt_image;
                }
            }
            elseif ( $crop == false ) 
            {
                // calculate the size proportionaly
                $proportional_size = wp_constrain_dimensions( $image_src[1], $image_src[2], $width, $height );
                $resized_img_path = $no_ext_path.'-'.$proportional_size[0].'x'.$proportional_size[1].$extension;			
                // checking if the file already exists
                if ( file_exists( $resized_img_path ) ) 
                {
                    $resized_img_url = str_replace( basename( $image_src[0] ), basename( $resized_img_path ), $image_src[0] );
                    $vt_image = array (
                    'url' => $resized_img_url,
                    'width' => $proportional_size[0],
                    'height' => $proportional_size[1]
                    );
                    return $vt_image;
                }
            }
            // check if image width is smaller than set width
            $img_size = getimagesize( $file_path );
            if ( $img_size[0] <= $width ) $width = $img_size[0];		
            // no cache files - let's finally resize it
            $new_img_path = image_resize( $file_path, $width, $height, $crop );
            $new_img_size = getimagesize( $new_img_path );
            $new_img = str_replace( basename( $image_src[0] ), basename( $new_img_path ), $image_src[0] );
            // resized output
            $vt_image = array (
            'url' => $new_img,
            'width' => $new_img_size[0],
            'height' => $new_img_size[1]
            );
            return $vt_image;
        }
        // default output - without resizing
        $vt_image = array (
        'url' => $image_src[0],
        'width' => $image_src[1],
        'height' => $image_src[2]
        );
        return $vt_image;
    }
}
if ( !function_exists('vt_resize2') ) 
{
    function vt_resize2( $img_name, $dir_url, $dir_path, $width, $height, $crop = false ) 
    {
        $file_path = trailingslashit($dir_path).$img_name;
        $orig_size = getimagesize( $file_path );
        $image_src[0] = trailingslashit($dir_url).$img_name;
        $image_src[1] = $orig_size[0];
        $image_src[2] = $orig_size[1];
        $file_info = pathinfo( $file_path );
        // check if file exists
        $base_file = $file_info['dirname'].'/'.$file_info['filename'].'.'.$file_info['extension'];
        if ( !file_exists($base_file) )
        return;
        $extension = '.'. $file_info['extension'];
        // the image path without the extension
        $no_ext_path = $file_info['dirname'].'/'.$file_info['filename'];
        // checking if the file size is larger than the target size
        // if it is smaller or the same size, stop right here and return
        if ( $image_src[1] > $width || $image_src[2] > $height ) 
        {
            if ( $crop == true ) 
            {
                $cropped_img_path = $no_ext_path.'-'.$width.'x'.$height.$extension;

                // the file is larger, check if the resized version already exists (for $crop = true but will also work for $crop = false if the sizes match)
                if ( file_exists( $cropped_img_path ) ) 
                {
                    $cropped_img_url = str_replace( basename( $image_src[0] ), basename( $cropped_img_path ), $image_src[0] );
                    $vt_image = array (
                    'url' => $cropped_img_url,
                    'width' => $width,
                    'height' => $height
                    );
                    return $vt_image;
                }
            }
            elseif ( $crop == false ) 
            {
                // calculate the size proportionaly
                $proportional_size = wp_constrain_dimensions( $image_src[1], $image_src[2], $width, $height );
                $resized_img_path = $no_ext_path.'-'.$proportional_size[0].'x'.$proportional_size[1].$extension;			
                // checking if the file already exists
                if ( file_exists( $resized_img_path ) ) 
                {
                    $resized_img_url = str_replace( basename( $image_src[0] ), basename( $resized_img_path ), $image_src[0] );
                    $vt_image = array (
                    'url' => $resized_img_url,
                    'width' => $proportional_size[0],
                    'height' => $proportional_size[1]
                    );
                    return $vt_image;
                }
            }
            // check if image width is smaller than set width
            $img_size = getimagesize( $file_path );
            if ( $img_size[0] <= $width ) $width = $img_size[0];		
            // no cache files - let's finally resize it
            $new_img_path = image_resize( $file_path, $width, $height, $crop );
            $new_img_size = getimagesize( $new_img_path );
            $new_img = str_replace( basename( $image_src[0] ), basename( $new_img_path ), $image_src[0] );
            // resized output
            $vt_image = array (
            'url' => $new_img,
            'width' => $new_img_size[0],
            'height' => $new_img_size[1]
            );
            return $vt_image;
        }
        // default output - without resizing
        $vt_image = array (
        'url' => $image_src[0],
        'width' => $image_src[1],
        'height' => $image_src[2]
        );
        return $vt_image;
    }
}
function truncate_post($amount,$quote_after=false) 
{
    $truncate = get_the_content(); 
    $truncate = apply_filters('the_content', $truncate);
    $truncate = preg_replace('@<script[^>]*?>.*?</script>@si', '', $truncate);
    $truncate = preg_replace('@<style[^>]*?>.*?</style>@si', '', $truncate);
    $truncate = strip_tags($truncate);
    $truncate = substr($truncate, 0, strrpos(substr($truncate, 0, $amount), ' ')); 
    echo $truncate;
    echo "...";
    if ($quote_after) echo('"');
}
function custom_truncate_post($quote,$amount,$quote_after=false) 
{
    $truncate = $quote; 
    $truncate = apply_filters('the_content', $truncate);
    $truncate = preg_replace('@<script[^>]*?>.*?</script>@si', '', $truncate);
    $truncate = preg_replace('@<style[^>]*?>.*?</style>@si', '', $truncate);
    $truncate = strip_tags($truncate);
    $truncate = substr($truncate, 0, $amount); 
    return $truncate . "...";
    if ($quote_after) echo('"');
}

//Home page Blogs
function homepage_blogs(){
    // ob_start();
 
     /* How to use custom thumbnail image function in while loop */
         $contet = '<div class="custom-elementor-shortcode">';
             
                  $args = array(
                      'post_type' => 'post',
                      'posts_per_page' => 3
                  );
                  $wp_query = new WP_Query($args);
                  if ($wp_query->have_posts()) :
                      $i=0;
                  while ($wp_query->have_posts()) : $wp_query->the_post();
                   $i++;
                 $image_id = get_post_thumbnail_id(); 
                 $image_url = etheme_get_resized_url($image_id,368,261,true);
                 
                 include( get_stylesheet_directory() .'/templates/loop-home-page-blogs.php'); 
                 
            endwhile; endif;wp_reset_postdata();
      $contet .= '</div>';
       
     return $contet;
     }
add_shortcode('homepage_blogs' , 'homepage_blogs');


//media_insights page Blogs
function media_insights(){
    //ob_start();
 
     /* How to use custom thumbnail image function in while loop */
         $contet = '<div class="custom-media-insights" id="ajax-data">';
             
                  $args = array(
                      'post_type' => 'post',
                      'status' => 'publish',
                      'posts_per_page' => 10,
                  );
                  $wp_query = new WP_Query($args);
                  if ($wp_query->have_posts()) :
                      $i=0;
                  while ($wp_query->have_posts()) : $wp_query->the_post();
                   $i++;
                 $image_id = get_post_thumbnail_id(); 
                 $image_url = etheme_get_resized_url($image_id,368,261,true);
                 $image_url1 = etheme_get_resized_url($image_id,800,450,true);
                  
                 include( get_stylesheet_directory() .'/templates/media-insights.php');     

            endwhile; endif;wp_reset_postdata();
      $contet .= '</div>';
      $contet .= '</div>';
      $contet .= '<div class="load-more" data-post-type="post" data-category="" data-offset="10" data-responce-cat="media-insights-blogs-wrapp">
                    <span class="loading-image">
                        <img src="'.get_site_url().'/wp-content/uploads/2022/09/loading.gif" alt="loading">
                    </span>
                    <span class="loading-text">Load More</span>
                </div>';
       
     return $contet;
     }
add_shortcode('media_insights' , 'media_insights');



// GLOBAL LOAD MORE BUTTON FUNSTION 
add_action( 'wp_ajax_nopriv_load_more', 'load_more' );
add_action( 'wp_ajax_load_more', 'load_more' );
function load_more()
{
	$number = $_POST['offset'];
    $page = $_POST['page'];
    $post_type = $_POST['post_type'];
    $category_slug = $_POST['category'];
    $offset = $number * ($page-1);
    $category = get_category_by_slug($category_slug);
 
    global $post;
    if($post_type ==  'post')
    {
        $argss = array(
            'post_type' => 'post',
            'posts_per_page' => $number,
            'status' => 'publish',
            'paged' => $paged,
            'offset'    => $offset,
        );
        $wp_query = new WP_Query($argss);
        if ($wp_query->have_posts()) : $i=0;
            while ($wp_query->have_posts()) : $wp_query->the_post(); $i++;
                $image_ids = get_post_thumbnail_id(); 
                $image_url2 = etheme_get_resized_url($image_ids,368,261,true);

                include( get_stylesheet_directory() .'/templates/loop-media-insights.php');
                
            endwhile; 
        endif; wp_reset_query();
    }
    elseif($post_type ==  'resource')
    {
        $argss = array(
            'post_type' => 'resource',
            'posts_per_page' => 1,
            'status' => 'publish',
            'posts_per_page' => $number,
            'paged' => $paged,
            'offset'    => $offset,
        );
        $wp_query = new WP_Query($argss);
        if ($wp_query->have_posts()) : $i=0;
            while ($wp_query->have_posts()) : $wp_query->the_post(); $i++;
                $image_ids = get_post_thumbnail_id(); 
                $image_url2 = etheme_get_resized_url($image_ids,400,225,true);
                $res_button_title = get_field('res_button_title',$post->ID);
                $attach_video_file = get_field('attach_video_file',$post->ID);
                $path_video_url = get_field('path_video_url',$post->ID);
                $upload_resource_document = get_field('upload_resource_document',$post->ID);
                $resource_document_url = get_field('resource_document_url_',$post->ID);
                $term_list = get_the_terms($post->ID, 'resource_cat');
                /*echo "<pre>";
                print_r($$path_video_url);*/

                include( get_stylesheet_directory() .'/templates/loop-resources-downloads.php');

            endwhile; 
        endif; wp_reset_query();
   
    }
	//return $contet;
exit();

}



function ajaxurl()
{
    ?>
    <script>
        var ajaxurl = "<?php echo admin_url('admin-ajax.php') ?>";
    </script>
    <?php 
}
add_action('wp_head','ajaxurl');

//Resources and Downloads
function resources_and_downloads(){
    ob_start();
    global $post;
    ?>

    <div class="custom-resource-insight-main" id="ajax-data">

    <?php

    $argss = array(
        'post_type' => 'resource',
        'posts_per_page' => 9,
        'status' => 'publish',
    );
    $wp_query = new WP_Query($argss);
    if ($wp_query->have_posts()) : $i=0;
        while ($wp_query->have_posts()) : $wp_query->the_post(); $i++;
            $image_ids = get_post_thumbnail_id(); 
            $image_url2 = etheme_get_resized_url($image_ids,400,225,true);
            $res_button_title = get_field('res_button_title',$post->ID);
            $attach_video_file = get_field('attach_video_file',$post->ID);
            $path_video_url = get_field('path_video_url',$post->ID);
            $upload_resource_document = get_field('upload_resource_document',$post->ID);
            $resource_document_url = get_field('resource_document_url_',$post->ID);
            $term_list = get_the_terms($post->ID, 'resource_cat');
            /*echo "<pre>";
            print_r($$path_video_url);*/
          
            include( get_stylesheet_directory() .'/templates/loop-resources-downloads.php');

        endwhile; 
    endif; wp_reset_query();
    ?>
</div>
<div class="load-more" data-post-type="resource" data-category="" data-offset="9" data-responce-cat="ajax-data">
    <span class="loading-image">
        <img src="<?php echo get_site_url();?>/wp-content/uploads/2022/09/loading.gif" alt="loading">
    </span>
    <span class="loading-text">Load More</span>
</div>
    <?php
 
}
add_shortcode('resources_and_downloads' , 'resources_and_downloads');

