<?php
    $contet .= '<div class="blog-inner">
            <div class="post-item">
                <div class="post-item-img">
                    <a class="images" href='.get_the_permalink().'><img class="img-responsive" src="'.$image_url.'" alt="'.get_the_title().'"></a>
                </div>
                <div class="article-content">';
                    foreach(get_the_category( $post->ID ) as $term){ 
                        $term_link = get_term_link($term->term_id);
                        $contet .= '<span class="cat">
                            <a href="'.$term_link.'">'.$term->name.'</a>
                        </span>';
                    }
                    $contet .= '<h2><a class="images" href="'.get_the_permalink().'">'. get_the_title().'</a>
                    </h2>
                    <p>'.wp_trim_words( get_the_excerpt(), 12, '...' ).'</p>
                </div>
            </div>
        </div>';
?>