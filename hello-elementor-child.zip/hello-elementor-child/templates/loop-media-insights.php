<div class="media-insights-inner-blogs">
    <div class="post-item">
        <div class="post-item-img">
            <a class="images" href="<?php the_permalink(); ?>">
                <img class="img-responsive" src="<?php echo $image_url2;?>" alt="<?php the_title(); ?>">
            </a>
        </div>
        <div class="article-content">
            <?php
                foreach(get_the_category( $post->ID ) as $term){ 
                    $term_link = get_term_link($term->term_id); ?>
                    <span class="cat">
                        <a href="<?php echo $term_link; ?>"><?php echo $term->name; ?></a>
                    </span>
                <?php } ?>
                <h4>
                    <a class="images" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </h4>
            <p><?php echo wp_trim_words( get_the_content(), 12, '...' );?></p>
        </div>
    </div>
</div>