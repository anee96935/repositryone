<div class="resources-inner-blogs">
    <div class="post-item">
        <div class="post-item-img">
            <a class="images" href="javascript:void(0)">
                <img class="img-responsive" src="<?php echo $image_url2;?>" alt="<?php the_title(); ?>">  
            </a>
            <?php if( (!empty($attach_video_file['subtype']) && $attach_video_file['subtype'] == 'mp4') || !empty($path_video_url) ){ ?>
                <div class="play-icon">
                    <?php if( (!empty($attach_video_file['subtype']) && $attach_video_file['subtype'] == 'mp4')){ ?>
                        <img class="play-icon-res" data-id="<?php echo $attach_video_file['url']; ?>" file-type="<?php echo $attach_video_file['subtype'] ?>"  src="https://www.diffuse-energy.com/hubfs/Assets%20December%202019/Play.svg">
                    <?php }else if(!empty($path_video_url)){ ?>
                        <img class="play-icon-res" data-id="<?php echo substr($path_video_url, strrpos($path_video_url, 'v') + 2) ?>" file-type="url"  src="https://www.diffuse-energy.com/hubfs/Assets%20December%202019/Play.svg">
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
        <div class="article-content">
            <?php if(!empty($term_list[0]->name)){ ?>
                <div class="resources-cat-name">
                    <?php 
                        if($term_list[0]->name == 'Video')
                        { 
                    ?>
                        <span class="video-icon">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/video.svg" alt="video" style="max-width: 100%; height: auto;">
                        </span>
                    <?php 
                        }
                        else
                        {
                    ?>
                        <span class="video-icon">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/pdf.svg" alt="video" style="max-width: 100%; height: auto;">
                        </span>
                    <?php
                        }
                    ?>
                    <span class="res-video"><?php echo $term_list[0]->name ?></span>
                </div>
            <?php } ?>
            <h4>
                <a class="images" href="javascript:void(0)"><?php the_title(); ?></a>
            </h4>
            <div class="res-link"> 
                <?php if(!empty($attach_video_file['url']) && $attach_video_file['subtype'] == 'mp4'){ ?>
                    <a href="<?php echo $attach_video_file['url']; ?>" target="_blank"><?php echo $res_button_title; ?></a>
                <?php }else if(!empty($path_video_url)){ ?>
                    <a href="<?php echo $path_video_url; ?>" target="_blank"><?php echo $res_button_title; ?></a>
                <?php }else if(!empty($upload_resource_document['url']) && $upload_resource_document['subtype'] == 'pdf'){ ?>
                    <a href="<?php echo $upload_resource_document['url']; ?>" target="_blank"><?php echo $res_button_title; ?></a>
                <?php }else if(!empty($resource_document_url)){ ?>
                    <a href="<?php echo $resource_document_url; ?>" target="_blank"><?php echo $res_button_title; ?></a>
                <?php }else{ ?>
                    <a href="javascript:void(0)"><?php echo $res_button_title; ?></a>
                <?php } ?>
            </div>
        </div>
    </div>
</div>