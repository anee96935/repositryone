jQuery(document).ready(function(){
    jQuery(document).on('click', '.close-top-bar', function(){
        jQuery(this).parents('.top-bar').hide();
    });
});

jQuery(document).ready(function() {
    jQuery(".loading-image").hide();
    var curr_page = 1;
    jQuery(document).on("click", ".load-more", function () {
        curr_page = curr_page + 1;
        var offset = jQuery(this).data('offset');
        var post_type = jQuery(this).data('post-type');
        var category = jQuery(this).data('category');
        var responce_cat = jQuery(this).data('responce-cat');
        var responce_cat = "#" + responce_cat;

        jQuery(".loading-text").hide();
        jQuery(".loading-image").show(); 
        jQuery.ajax({
            type: 'POST',
            url:  ajaxurl,
            data: {"action": "load_more",'offset': offset, 'page': curr_page,'post_type': post_type,'category': category},
            success: function(response) {
                if( jQuery.trim(response) != '' ) {
                    jQuery( responce_cat ).append( response );
                    jQuery(".loading-text").show();
                    jQuery(".loading-image").hide();
                    // page++;
                  } else {
                    jQuery('.ld_mre').hide();      
                }
                  console.log(response)
            },
            error: function(data) {
                console.log(data);
            }
        });
    });
});


jQuery(document).ready(function() {

    /* jQuery("#play-icon-res").click(function(){
       var video_url = jQuery(this).attr("data-id");
       jQuery(".video-popup-main").html('<source src="'+ video_url +'" type="video/mp4">');
    });*/

});


jQuery(document).ready(function() {
    jQuery(".play-icon-res").click(function(){
        var video_url = jQuery(this).attr("data-id");
        var file_type = jQuery(this).attr("file-type");

        //console.log(video_url+" | " + file_type);
        //console.log("Test: "+video_url+" | " + file_type);

        //jQuery('#video_url').attr('src', video_url);
        if(file_type == 'mp4')
        {
            jQuery('#video_popup').html('<div class="ratio ratio-16x9"><video controls class="video-class" id="video" preload="metadata" poster="poster.jpg"><source id="video_url"  src="'+video_url+'" type="video/mp4"></source></video></div>');
        }
        else if(file_type == 'url')
        {
            jQuery('#video_popup').html('<div class="ratio ratio-16x9"><iframe class="embed-responsive-item" src="https://www.youtube.com/embed/'+video_url+'" width="100%" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></div>');
        }
        jQuery("#popup_box").removeClass('hide');
        jQuery("#popup_box").css('display:block');
    });

    jQuery(".close").click(function(){
        jQuery("#popup_box").addClass('hide');
        jQuery('#video_popup iframe').attr('src', '');
        var vid = document.getElementById("video"); 
        vid.pause(); 
    });
});
 
