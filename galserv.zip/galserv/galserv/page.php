<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package galserv
 */

get_header();
?>
<?php
		while ( have_posts() ) :
			the_post();
			?>
<section class="module module__inner-hero module__inner-hero--cap">
	<div class="top-section">
		<div class="container">
			<div class="content-top-section-wrapper aos-init" data-aos-once="true" data-aos="fade-in">
				<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
				<?php //the_content();?>
			</div>
		</div>
		<div class="triangle-shape"></div>
	</div>
</section>

<section class="module module__image-copy module__image-copy--certifications bg-none p-relative index-2 default-pages">
	<div class="image-content-block">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12 content-col">
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">

		<?php
		//while ( have_posts() ) :
			//the_post();

			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		
		?>

					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php endwhile; // End of the loop. ?>
<?php
//get_sidebar();
get_footer();
