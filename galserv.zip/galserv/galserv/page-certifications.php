<?php
/**
 * The template for displaying all pages
 * Template Name: Certifications
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package galserv
 */

get_header();

while ( have_posts() ) :
the_post(); 


?>

<!-- Inner Hero Section Start -->
<section class="module module__inner-hero module__inner-hero--certifications">
	<div class="top-section">
		<div class="container">
			<div class="content-top-section-wrapper aos-init" data-aos-once="true" data-aos="fade-in">
				<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
				<?php the_content();?>
			</div>
		</div>
		<div class="triangle-shape"></div>
	</div>
</section>
<?php $backgroung_image=get_field('backgroung_image');
if(!empty($backgroung_image)){ ?>
<div class="module__inner-hero--shape" style="background-image:url(<?php echo $backgroung_image; ?>);"> </div>
<?php }?>
<!-- Inner Hero Section End -->
<section class="module module__image-copy module__image-copy--certifications bg-none p-relative index-2">
	<div class="image-content-block">
		<div class="container">
			<div class="row"> 
				<div class="col-md-6 col-lg-6 content-col">
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">
						<?php $heading=get_field('heading_');
						if(!empty($heading)){ ?>
						<h3><?php echo $heading;?></h3>
						<?php } ?>
						<?php $content=get_field('content');
						if(!empty($content)){?>
						<p><?php echo $content;?></p>
						<?php }?>	
					</div>
				</div>
				<div class="col-md-6 col-lg-6 image-col">
					<div class="media-wrapper height-auto aos-init" data-aos="fade-left" data-aos-once="true">
						<?php $image1=get_field('image1'); if(!empty($image1)){ ?>
						<div class="media-container">
							<img src="<?php echo esc_url($image1['url']); ?>" alt="<?php echo esc_attr($image1['alt']); ?>" class="img-responsive">

						</div>
						<?php
						}?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section id="" class="module module__image-copy module__image-copy--reverse p-relative">
	<div class="image-content-block p-relative index-2">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-6 content-col">
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">
						<?php $heading1=get_field('heading1');
						if(!empty($heading1)){ ?>
						<h3><?php echo $heading1;?></h3>
					   <?php }?>
					    <?php $content1=get_field('content1');
					     if(!empty($content1)){?>
						<p><?php echo $content1;?></p>
					<?php }?>
						<?php // Check rows exists.
						if( have_rows('nav_area_button') ):
					    // Loop through rows.
					    while( have_rows('nav_area_button') ) : the_row();
					    // Load sub field value.
					    $buttonText = get_sub_field('button_text');
					    $buttonUrl = get_sub_field('button_url');
					    // Do something...?>
						<div class="button--wrapper"><a href="<?php echo $buttonUrl; ?>" class="btn btn-link"><?php if(!empty($buttonText)){echo $buttonText;}?></a></div>
						<?php  // End loop. 
					endwhile; endif; ?>
					</div>
				</div>
				<div class="col-md-6 col-lg-6 image-col">
					<div class="media-wrapper bg-grey height-auto padding-bg aos-init" data-aos="fade-left" data-aos-once="true">
						<?php $image2=get_field('image2');if(!empty($image2)){?>
						<div class="media-container">
							<img src="<?php echo esc_url($image2['url']); ?>" alt="<?php echo esc_attr($image2['alt']); ?>" class="img-responsive" />
						</div>
					<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="bottom-cert-bg"></div>
</section>

<section id="" class="module module__image-copy module__image-copy--env">
	<div class="image-content-block">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-6 content-col">
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">
						<?php $heading3=get_field('heading3');
						if(!empty($heading3)){?>
						<h3><?php echo $heading3;?></h3>
						<?php }?>
						<?php $content3=get_field('content3');
						if(!empty($content3)){?>
						<p><?php echo $content3;?></p>
						<?php }?>
						<?php $button=get_field('button');
						$button_url=get_field('button_url');
						if(!empty($button) || !empty($button_url) ){ ?>
						<a href="<?php echo $button_url;?>" class="btn btn-link"><?php echo $button; ?></a>
						<?php
						}?>
					</div>
				</div>
				<div class="col-md-6 col-lg-6 image-col">
					<div class="media-wrapper bg-grey  aos-init" data-aos="fade-left" data-aos-once="true">
						<?php $image=get_field('image');if(!empty($image)){?>
						<div class="media-container">
							<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" class="img-responsive" />
						</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $ctaBackgroundImage=get_field('cta_background_image');if(!empty($ctaBackgroundImage)){ ?>
<section class="module module__cta" style="background-image: url('<?php echo $ctaBackgroundImage;?>');">
	<div class="container">
		<div class="module__cta--wrapper aos-init" data-aos="fade-up" data-aos-delay="100" data-aos-once="true">
			<?php $heading4=get_field('heading4');
			if(!empty($heading4)){ ?>
			<h3><?php echo $heading4;?></h3>
			<?php }?>
			<?php $content4=get_field('content4');
			if(!empty($content4)){ ?>
			<p><?php echo $content4;?></p>
			<?php }?>
			<?php $contact_us=get_field('contact_us');
				if(!empty($contact_us) || !empty($contact_url)){?>
			<a class="btn btn-link" href="<?php echo $contact_url;?>"><?php echo $contact_us;?></a>
			<?php
		      }?>
		</div>
	</div>
</section>
<?php } ?>
<!-- CTA Section End -->
<div class="triangle-shape-inverted"></div>

<?php endwhile; // End of the loop. ?>
<?php
//get_sidebar();
get_footer();
