<?php
/**
 * The template for displaying all pages
 * Template Name: Our Capabilities
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package galserv
 */

get_header();

while ( have_posts() ) :
the_post(); ?>

<!-- Inner Hero Section Start -->
<section class="module module__inner-hero module__inner-hero--cap">
	<div class="top-section">
		<div class="container">
			<div class="content-top-section-wrapper aos-init" data-aos-once="true" data-aos="fade-in">
				<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
				<?php the_content();?>
			</div>
		</div>
		<div class="triangle-shape"></div>
	</div>
</section>
<?php $featuredUrl = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'full' ); if(!empty($featuredUrl)){?>
<div class="module__inner-hero--shape" style="background-image:url(<?php echo $featuredUrl;?>);"></div>
<?php } ?>
<?php
$contentHeadings = get_field( "content_headings" );
$contentImage = get_field( "image" );
$darkContent = get_field( "d_content" );
$dImage = get_field( "d_image" );
$facilitiesTitle = get_field( "facilities_title" );
$brandTitle=get_field('brand_title');

$moreButton=get_field('more_button');
$readButtonUrl=get_field('read_more_button_url');

$CapabilityTitle=get_field('title_');
$ctaContent=get_field('cta_content');
$ctaBackgroundImage=get_field('cta_background_image');

?>
<!-- Inner Hero Section End -->
<section class="module module__image-copy module__image-copy--certifications bg-none p-relative index-2">
	<div class="image-content-block">
		<div class="container">
			
			<div class="row">
				<?php if( $contentHeadings ) { ?>
				<div class="col-md-6 col-lg-6 content-col">
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">
						<?php  echo $contentHeadings; ?>
						
					</div>
				</div>
				<?php } ?>
				<div class="col-md-6 col-lg-6 image-col">
					<div class="media-wrapper height-auto aos-init" data-aos="fade-left" data-aos-once="true">
					<?php 	if( !empty( $contentImage ) ): ?>
						<div class="media-container">
							<img src="<?php echo esc_url($contentImage['url']); ?>" alt="<?php echo esc_attr($contentImage['alt']); ?>" />
						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section id="" class="module module__image-copy module__image-copy--env">
	<div class="image-content-block">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-5 content-col">
					<?php 	if( !empty( $darkContent ) ): ?>
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">
						<?php  echo $darkContent; ?>
					</div>
					<?php endif; ?>
				</div>
				<div class="col-md-6 col-lg-7 image-col">
					<div class="media-wrapper mw-none bg-none aos-init" data-aos="fade-left" data-aos-once="true">
						<?php 	if( !empty( $dImage ) ): ?>
						<div class="media-container">
							<img src="<?php echo esc_url($dImage['url']); ?>" alt="<?php echo esc_attr($dImage['alt']); ?>" />
						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section id="sandblasting" class="module module__image-copy module__image-copy--reverse padding-mob">
	<div class="image-content-block">
		<div class="container">
			<div class="facility-cap-wrapper">
				<div class="facility-list">
					
					<?php if( $facilitiesTitle ) { echo $facilitiesTitle; } ?>
					<ul class="facility-list--wrapper">
						<?php

						// Check rows exists.
						if( have_rows('facilities_list_box') ):
						    // Loop through rows.
						    while( have_rows('facilities_list_box') ) : the_row();
						        // Load sub field value.
						        $faciliTiesList = get_sub_field('facilities_list');
						        // Do something...
						    ?>
						<li>
							<div class="list">
								<?php echo  $faciliTiesList; ?>
							</div>
						</li>
						<?php endwhile; endif; ?>
					</ul>
				</div>
				<div class="cap-list">
					<?php if( $CapabilityTitle ) { echo $CapabilityTitle; } ?>
					<div class="cap-list__wrapper">
						<ul>
							<?php // Check rows exists.
							if( have_rows('content_icon') ):
						    // Loop through rows.
						    while( have_rows('content_icon') ) : the_row();
						    // Load sub field value.
						    $svgIcon = get_sub_field('svg_icon');
						    $capContent = get_sub_field('content');
						    // Do something...?>
							<li>
								<div class="list-inner">
									<div class="icon">
										<img src="<?php echo esc_url($svgIcon['url']); ?>" alt="<?php echo esc_attr($svgIcon['alt']); ?>" />
									</div>
									<?php echo $capContent; ?>
								</div>
							</li>
							<?php  // End loop. 
							endwhile; endif; ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="module module__news module__membership--cap">
	<div class="module__news--wrapper">
		<div class="container aos-init" data-aos="fade-in" data-aos-delay="00" data-aos-once="true">
			<div class="module__membership">
				<?php if( $brandTitle ) { echo $brandTitle; } ?>
				<div class="module__membership--icon aos-init" data-aos="fade-in" data-aos-delay="00" data-aos-once="true">
					<?php

						// Check rows exists.
						if( have_rows('brand_logos') ):

						    // Loop through rows.
						    while( have_rows('brand_logos') ) : the_row();

						        // Load sub field value.
						        $brandLogo = get_sub_field('logo');
						        // Do something...

						    // End loop.
						    ?>
					<div>
						<img src="<?php echo esc_url($brandLogo['url']); ?>" alt="<?php echo esc_attr($brandLogo['alt']); ?>" />
					</div>
				<?php endwhile; endif; ?>
				</div>
				<div class="button--wrapper aos-init" data-aos="fade-up" data-aos-delay="00" data-aos-once="true">
					<a href="<?php if( $readButtonUrl ) { echo $readButtonUrl; } ?>" class="btn-link"><?php if( $moreButton ) { echo $moreButton; } ?></a>
				</div>
			</div>
		</div>
	</div>
	<div class="membership-bg"></div>
</section>
<!-- CTA Section Start-->
<section class="module module__cta" style="background-image: url('<?php echo $ctaBackgroundImage;?>');">
	<div class="container">
		<div class="module__cta--wrapper aos-init" data-aos="fade-up" data-aos-delay="100" data-aos-once="true">
			<?php if( $ctaContent ) { echo $ctaContent; } ?>
		</div>
	</div>
</section>
<!-- CTA Section End -->

<?php endwhile; // End of the loop. ?>
<?php
//get_sidebar();
get_footer();
