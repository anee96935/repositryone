jQuery(document).ready(function($){
    $(document.body).removeClass('no-js').addClass('js');


    // Utilities
    initMobileMenu();
    initClassToggle();
    initSlick();
    initAccordionTabs();
});
function initClassToggle() {
    $(document.body).on('click', '[data-toggle="class"][data-class]', function(event) {
        var $body = $('body');
        var $trigger = $(this);
        var $target = $($trigger.data('target') ? $trigger.data('target') : $trigger.attr('href'));

        if($target.length) {
            event.preventDefault();
            $target.toggleClass($trigger.data('class'));
            $trigger.toggleClass('classed');
            $body.toggleClass('scroll-hidden');
        }
    });
}

function initSlick() {
    $('.module__news--wrapper--lists').slick({
      dots: false,
      focusOnSelect: false,
      infinite: true,
      arrows: true,
      speed: 300,
      slidesToShow: 3,
      slidesToScroll: 1,
      autoplay: false,
      adaptiveHeight: false,
      autoplaySpeed: 4000,
      responsive: [
         {
            breakpoint: 1024,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
            }
        },
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }
        ]
    });
    $('.project-slider').slick({
      dots: false,
      focusOnSelect: false,
      infinite: true,
      arrows: true,
      speed: 300,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: false,
      adaptiveHeight: false,
      autoplaySpeed: 4000
    });
}


function initAccordionTabs() {
    const $accordionTabs = $('.accordion-tabs');
    if (!$accordionTabs.length) {
        return;
    }

    function initTabs() {
        const $tabs = $accordionTabs.find('.accordion-tabs__tabs');
        if (!$tabs.length) {
            return;
        }
        const $triggers = $tabs.find('.tabs__link');
        $triggers.each((_, trigger) => {
            $(trigger).on('click', (e) => {
                e.preventDefault();
                const target = $(trigger).data('target');
                if(target && !$(trigger).hasClass('active')) {
                    $(trigger).parent().find('.active').removeClass('active');
                    $(trigger).addClass('active');
                    $tabs.find('.tabs__content.show').removeClass('show');
                    $tabs.find(target).addClass('show');
                }
            })
        })
    }
    initTabs();
    function autoSlides(){
        const $slide_tabs = $accordionTabs.find('.accordion-tabs__tabs');
        const $slide_triggers = $slide_tabs.find('.tabs__link');
        const targets = $($slide_triggers).data('target');
        $($slide_triggers).parent().find('.active').next().addClass('active');
       const $slider_active =  $($slide_triggers).parent().find('.active').prev().removeClass('active');
         const $slider_target =   $($slide_triggers).parent().find('.active').data('target');
         $slide_tabs.find('.tabs__content.show').removeClass('show');
        $slide_tabs.find($slider_target).addClass('show');
    }
    window.setInterval(autoSlides, 5000);
}

/**
 * Mobile menu
 */
function initMobileMenu() {
    $('.mobile-menu-toggle a').click(function(e){
        e.preventDefault();
        var thisparent = $(this).closest('header');
        $('.header-main__menu--mobile', thisparent).slideToggle();
    });

    var menuItemWithChildren = $('.menu-item-has-children');
    if(menuItemWithChildren.length) {
        menuItemWithChildren.each(function() {
            var li = $(this);
            var anchor = li.find('> a');

            if(anchor.length) {
                anchor.on('click', function(e) {
                    li.toggleClass('menu-active');
                    e.preventDefault();
                    e.stopPropagation();
                });
            }
        });
    }
}

AOS.init();
//Recalc on load to account for page jump resetting anchors.
window.addEventListener("load", AOS.refresh);
