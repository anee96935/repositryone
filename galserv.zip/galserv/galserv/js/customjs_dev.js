//custom js for title header

	jQuery(document).ready(function($){  
		
	jQuery('.entry-title').html(function(){	
		// separate the text by spaces
		var text= jQuery(this).text().split(' ');
		// drop the last word and store it in a variable
		var last = text.pop();
		// join the text back and if it has more than 1 word add the span tag
		// to the last word
		return text.join(" ") + (text.length > 0 ? ' </br><span>'+last+'</span>' : last);   
	});

});
