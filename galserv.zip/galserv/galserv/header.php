<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package galserv
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel='stylesheet' id='slickcsstheme-css'  href='https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css' type='text/css' media='all' />
	<link rel='stylesheet' id='slickcss-css'  href='https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css' type='text/css' media='all' />
	<!-- Bootstrap style -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css">
	

	<!-- Animation css -->
	 <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
		<div class="container-fluid">
			<button class="site-header__nav-toggle" type="button" data-toggle="class" data-target="#site-nav" data-class="site-header__nav--visible">
				<svg class="logo--img hamburger" xmlns="http://www.w3.org/2000/svg" width="42.358" height="39" viewBox="0 0 42.358 39">
				  <g id="Component_130_1" data-name="Component 130 – 1" transform="translate(0 3.5)">
				    <line id="Line_69" data-name="Line 69" x2="42.358" fill="none" stroke="#fff" stroke-width="7"/>
				    <line id="Line_70" data-name="Line 70" x2="42.358" transform="translate(0 16)" fill="none" stroke="#fff" stroke-width="7"/>
				    <line id="Line_71" data-name="Line 71" x2="42.358" transform="translate(0 32)" fill="none" stroke="#fff" stroke-width="7"/>
				  </g>
				</svg>
				<svg class="logo--img close" width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
				<line x1="21.6464" y1="21.5667" x2="0.433242" y2="0.353548" stroke="white"/>
				<line y1="-0.5" x2="30" y2="-0.5" transform="matrix(0.707107 -0.707107 -0.707107 -0.707107 0 21.2132)" stroke="white"/>
				</svg>
			</button>
			
			
			<?php 
				$topLogo = get_field('header_logo', 'option'); 
				if( !empty( $topLogo ) ): ?>
				<a class="site-header__logo" href="<?php echo home_url();?>">
    				<img class="animate__animated animate__fadeInLeft" src="<?php echo esc_url($topLogo['url']); ?>" alt="<?php echo esc_attr($topLogo['alt']); ?>" />
				<?php endif; ?>
				</a>
			
			<div id="site-nav" class="site-header__nav">
				<nav class="site-header__top-nav">
						<?php 
							$args = array(
							'theme_location' => 'menu-1',       
		   					'menu' => 'menu-main-menu');
							wp_nav_menu( $args ); 
						?>

				</nav>
			</div>
		</div>
	</header>
<!-- Header End -->
