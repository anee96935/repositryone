<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package galserv
 */

?>

<?php 
$columnHheading = get_field('column_heading', 'option');
$footerLocation = get_field('footer_location', 'option');
$phone1 = get_field('phone_1', 'option');
$phone2 = get_field('phone_2', 'option');
$emailAddress = get_field('email_address', 'option');
$socialMediaHeading=get_field('social_media_heading', 'option');
$socialMediaLinks = get_field('social_media_links', 'option');
$footerCol2Heading = get_field('footer_col2_heading', 'option');

$plantOperationHour=get_field('plant_operation_hour', 'option');
$column3Heading=get_field('column_3_heading', 'option');
$contactForm=get_field('contact_form', 'option');
$copyrightText=get_field('copyright_text', 'option');
$designedText=get_field('designed_by_text', 'option');

?>
<footer>
	<div class="footer__wrapper">
		<div class="container">
			<div class="footer__top">
				<div class="footer__top--left-col">
				<?php  if( !empty( $columnHheading ) || !empty( $footerLocation ) || !empty( $phone1 ) || !empty( $phone2 ) || !empty($emailAddress) || !empty( $socialMediaLinks ) || !empty($socialMediaHeading)): ?>
					<h5><?=$columnHheading;?></h5>
					<p class="address"><?=$footerLocation;?></p>
     				<p><a href="tel:<?=trim($phone1);?>" target="_blank">
     					<svg xmlns="http://www.w3.org/2000/svg" width="15.733" height="15.734" viewBox="0 0 15.733 15.734">
						  <path id="Icon_awesome-phone" data-name="Icon awesome-phone" d="M15.161.756l-3.2-.738a.742.742,0,0,0-.845.427L9.645,3.887a.736.736,0,0,0,.212.86L11.72,6.271a11.389,11.389,0,0,1-5.445,5.445L4.75,9.855a.737.737,0,0,0-.86-.212L.448,11.118a.746.746,0,0,0-.43.848l.737,3.2a.737.737,0,0,0,.719.572A14.257,14.257,0,0,0,15.733,1.475.737.737,0,0,0,15.161.756Z" transform="translate(0.001 0.001)" fill="#007994"/>
						</svg>
						<?=$phone1;?></a></p>
     				<p><a href="tel:<?=($phone2);?>" target="_blank">
     					<svg xmlns="http://www.w3.org/2000/svg" width="14.09" height="14.09" viewBox="0 0 14.09 14.09">
						  <path id="Icon_awesome-fax" data-name="Icon awesome-fax" d="M1.761,3.522H.881A.881.881,0,0,0,0,4.4v8.806a.881.881,0,0,0,.881.881h.881a.881.881,0,0,0,.881-.881V4.4A.881.881,0,0,0,1.761,3.522ZM13.209,4.4V2.126a.881.881,0,0,0-.258-.623L11.706.258A.881.881,0,0,0,11.083,0H4.4a.881.881,0,0,0-.881.881V13.209a.881.881,0,0,0,.881.881h8.806a.881.881,0,0,0,.881-.881V5.284A.881.881,0,0,0,13.209,4.4ZM7.925,11.888a.44.44,0,0,1-.44.44H6.6a.44.44,0,0,1-.44-.44v-.881a.44.44,0,0,1,.44-.44h.881a.44.44,0,0,1,.44.44Zm0-3.522a.44.44,0,0,1-.44.44H6.6a.44.44,0,0,1-.44-.44V7.485a.44.44,0,0,1,.44-.44h.881a.44.44,0,0,1,.44.44Zm3.522,3.522a.44.44,0,0,1-.44.44h-.881a.44.44,0,0,1-.44-.44v-.881a.44.44,0,0,1,.44-.44h.881a.44.44,0,0,1,.44.44Zm0-3.522a.44.44,0,0,1-.44.44h-.881a.44.44,0,0,1-.44-.44V7.485a.44.44,0,0,1,.44-.44h.881a.44.44,0,0,1,.44.44Zm.44-3.082H4.843V1.321h5.724V2.2a.44.44,0,0,0,.44.44h.881Z" fill="#007994"/>
						</svg><?=$phone2;?>
					</a></p>
     				<p><a href="mailto:<?=$emailAddress;?>" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="15.733" height="12.587" viewBox="0 0 15.733 12.587">
					  <path id="Icon_material-email" data-name="Icon material-email" d="M17.16,6H4.573A1.571,1.571,0,0,0,3.008,7.573L3,17.013a1.578,1.578,0,0,0,1.573,1.573H17.16a1.578,1.578,0,0,0,1.573-1.573V7.573A1.578,1.578,0,0,0,17.16,6Zm0,3.147L10.866,13.08,4.573,9.147V7.573l6.293,3.933L17.16,7.573Z" transform="translate(-3 -6)" fill="#007994"/>
					</svg>
					<?=$emailAddress;?></a></p>
     				<p class="connect-copy"><?=$socialMediaHeading;?>
	     				<svg xmlns="http://www.w3.org/2000/svg" width="29.614" height="29.614" viewBox="0 0 29.614 29.614">
						  <path id="Icon_awesome-linkedin" data-name="Icon awesome-linkedin" d="M27.5,2.25H2.109A2.124,2.124,0,0,0,0,4.385V29.729a2.124,2.124,0,0,0,2.109,2.135H27.5a2.13,2.13,0,0,0,2.115-2.135V4.385A2.13,2.13,0,0,0,27.5,2.25ZM8.95,27.633H4.561V13.5h4.4V27.633ZM6.756,11.57A2.545,2.545,0,1,1,9.3,9.025,2.546,2.546,0,0,1,6.756,11.57ZM25.4,27.633H21.014V20.759c0-1.639-.033-3.748-2.281-3.748-2.287,0-2.637,1.785-2.637,3.629v6.994H11.707V13.5h4.211v1.93h.059a4.623,4.623,0,0,1,4.158-2.281c4.442,0,5.268,2.928,5.268,6.736Z" transform="translate(0 -2.25)" fill="#007994"/>
						</svg>
					</p>
				<?php endif; ?>
				</div>

			
				<div class="footer__top--middle-col">
				<?php  if(!empty($footerCol2Heading)){?>
					<h5><?=$footerCol2Heading?></h5>
				<?php }?>
				<?php 	$rows = get_field('trading_hours', 'option');
						if( $rows ) {
    					echo '<ul>';
    					foreach( $rows as $row ) {
				        $trandingDay = $row['day'];
				        $trandingTime = $row['time'];
				        echo '<li><span>';
			            echo $trandingDay;
			            echo '</span><span>';
			            echo  $trandingTime;
        				echo '</span></li>';
						    }
						    echo '</ul>';
						} ?>
						<?php  if(!empty($plantOperationHour)){
						echo '<p class="opertaional-copy">'.$plantOperationHour.'</p>'; } ?>
				</div>
				<div class="footer__top--right-col">
					<div class="footer-content-wrapper">
						<div class="logo-desktop-wrapper hidden-mobile">
							<div class="wrapper-logo">

						<?php $footerLogos = get_field('footer_logo', 'option');
						if( $footerLogos ) {
    					foreach( $footerLogos as $footerLogo ) {
				        $brandLogo = $footerLogo['brand_logo']; 
				        echo '<div>'; ?>
				       	<img src="<?php echo esc_url($brandLogo['url']); ?>" alt="<?php echo esc_attr($brandLogo['alt']); ?>" />
			           <?php  echo '</div>';
						    }
						 
						} ?>
							</div>
						</div>
						<div class="visible-mobile visible-mobile-logo-top">
							<?php 
							$topLogo = get_field('header_logo', 'option'); 
							if( !empty( $topLogo ) ): ?>
			    				<img src="<?php echo esc_url($topLogo['url']); ?>" alt="<?php echo esc_attr($topLogo['alt']); ?>" />
							<?php endif; ?>
						</div>
						<?php  if(!empty($column3Heading)){
						echo '<h5>'.$column3Heading.'</h5>'; } ?>
						
						<div class="form-wrapper">
						<?php if(!empty($contactForm)) : ?>
							<?php echo $contactForm;?>
						<?php endif;?>
						</div>
						<div class="visible-mobile visible-mobile-logo-bottom">
							<?php 
							$topLogo = get_field('header_logo', 'option'); 
							if( !empty( $topLogo ) ): ?>
			    				<img src="<?php echo esc_url($topLogo['url']); ?>" alt="<?php echo esc_attr($topLogo['alt']); ?>" />
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footer__bottom">
		<div class="container">
			<div class="footer__bottom--wrapper">
				<?php if( !empty( $copyrightText ) || !empty( $designedText ) ): ?>
				<div class="left-content"><?php echo $copyrightText;?></div>
				<div class="center-content"><?php echo $designedText;?></div>
				<?php endif; ?>
				<div class="contact-link">
					<?php $footerMenu = get_field('footer_menu', 'option');
						if( $footerMenu ) {
    					foreach( $footerMenu as $footerMenus ) {
				        $footerMenuText = $footerMenus['footer_menu_text']; 
				        $footerMenuUrl = $footerMenus['footer_menu_url']; 
				       	echo '<a href="'.$footerMenuUrl.'">'.$footerMenuText.'</a>';
						    }
						 
						} ?>
				</div>
			</div>
		</div>
	</div>
</footer>




<?php wp_footer(); ?>

</body>
</html>
