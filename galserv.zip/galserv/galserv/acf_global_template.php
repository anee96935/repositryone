<?php
/**
 * The template for displaying all pages
 * Template Name: ACF Global Template
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package galserv
 */

get_header();

?>


<!-- Banner Section Start -->

<?php

// Check value exists.
if( have_rows('flexible_content') ):

    // Loop through rows.
    while ( have_rows('flexible_content') ) : the_row();

      get_template_part( 'flexible-content/'. get_row_layout() );

 		// End loop.
endwhile; endif;?>



<?php get_footer(); ?>
