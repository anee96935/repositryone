<?php
/**
 * The template for displaying all pages
 * Template Name: Home
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package galserv
 */

get_header();

?>


<?php  	$bannerImage = get_field('banner_image');
	    $bannerHeadingline1 = get_field('heading_line1');
	    $bannerHeadingline2 = get_field('heading_line2');
	    $bannerHeadingline3 = get_field('heading_line3');
	    $bannerSub_title = get_field('banner_sub_title');
	    $aboutContent = get_field('about_content');
	    //$bannerButton = get_sub_field('banner_button');
	   // $buttonLink = get_sub_field('button_link');
	    // Do something...
         
?>
<section class="module module__hero">
<?php  if(!empty($bannerImage) || !empty($bannerHeadingline1) || !empty($bannerHeadingline2) || !empty($bannerHeadingline3) || !empty($bannerSub_title) || !empty($aboutContent)){ ?>
	<div class="module__hero__content-bg">
		<div class="media-wrapper">
			<img src="<?php echo esc_url($bannerImage['url']); ?>" alt="<?php echo esc_attr($bannerImage['alt']); ?>" />
			<div class="overlay"></div>
		</div>
	</div>
	<div class="triangle-shape-content">
		<div class="container">
			<div class="content aos-init" data-aos="fade-in" data-aos-delay="300" data-aos-once="true">
				<div class="heading-1 heading-font heading-white"><?= $bannerHeadingline1; ?></div>
				<div class="heading-2 heading-white">
					<span class="heading-font"><?= $bannerHeadingline2; ?></span>
					<span class="normal-tex"><?= $bannerSub_title; ?></span>
				</div>
				<div class="heading-1 heading-font heading-blue"><?= $bannerHeadingline3;?></div>
			</div>
			<div class="hero__banner--content-bottom hidden-mobile aos-init" data-aos="fade-in" data-aos-delay="400" data-aos-once="true">
				<?=$aboutContent;?>
				
			</div>
		</div>
	</div>
	<?php } ?>
</section>


<?php 
$tabHeading = get_field('tab_heading'); ?>

<!-- Services section Start -->
<?php // check if the repeater field has rows of data
if( have_rows('vertical_tab_block') ): ?>


	<section class="module module__services accordion-tabs">
		<div class="container aos-init  aos-init" data-aos="fade-up" data-aos-delay="100" data-aos-once="true">
			<?php if($aboutContent){ ?>
			<div class="hero__banner--content-bottom visible-mobile">
				<?=$aboutContent;?>
			</div>
		<?php } ?>
			<div class="module__services--wrapper">
				<?php if(!empty($tabHeading)){echo $tabHeading; } ?>
				
				<div class="module__services--tabs">
					<div class="accordion-tabs__container">
						<div class="accordion-tabs__tabs hidden-mobile inview-animation">
							<div class="tabs-col tabs-col--left inview-anime">

								<?php   

					 	// loop through the rows of data for the tab header
								$i = 0;
								while ( have_rows('vertical_tab_block') ) : the_row(); $i++;
									
									$accordionHeader = get_sub_field('accordion_header');?>

									<button type="button" class="btn btn--link-sm tabs__link <?php if($i==1){echo 'active';}?>" data-target="#accordion-tabs__tabs-<?php echo $i; ?>">
										<?php echo $accordionHeader; ?>
									</button>
								<?php endwhile; //End the loop ?>
							</div>
							<div class="tabs-col tabs-col--right inview-anime">
								<?php $j=0; while ( have_rows('vertical_tab_block') ) : the_row();  $j++;
								$accordionContent = get_sub_field('accordion_content');
								$accordionImage = get_sub_field('accordion_image');
								?>
								<div class="tabs__content <?php if($j==1){echo 'show';}?>" id="accordion-tabs__tabs-<?php echo $j; ?>">
									<div class="tabs__content__inner typography">
										<div class="content">
											<?php echo $accordionContent; ?>
										</div>
										<div class="media-wrapper">
											<img src="<?php echo esc_url($accordionImage['url']); ?>" alt="<?php echo esc_attr($accordionImage['alt']); ?>" />
										</div>
									</div>
									
								</div>
								<?php 
							endwhile; //End the loop ?>
						</div>
					</div>
					<div class="accordion-tabs__accordions hidden-desktop inview-animation">
						<?php $k=0; while ( have_rows('vertical_tab_block') ) : the_row();  $k++;
						$accordionHeader = get_sub_field('accordion_header');
						$accordionContent = get_sub_field('accordion_content');
						$accordionImage = get_sub_field('accordion_image'); 
						if($k==1) {
							?>
							
							<div class="accordion inview-anime">
								<a href="#" class="btn btn--link-sm accordion__link <?=$key==0 ? 'class-toggled': '';?>"
									data-target="#accordion-tabs__accordions-<?php echo $k; ?>" data-toggle="class" data-class="show" >
									<?php echo $accordionHeader; ?>
								</a>
								<div class="accordion__content show" id="accordion-tabs__accordions-<?php echo $k; ?>">
									<div class="accordion__content__inner typography">
										<div class="content">
											<?php echo $accordionContent; ?>
										</div>
										<div class="media-wrapper">
											<img src="<?php echo esc_url($accordionImage['url']); ?>" alt="<?php echo esc_attr($accordionImage['alt']); ?>" />
										</div>
									</div>
								</div>
							</div>
						<?php } else{ ?>
							
							<a href="#" class="btn btn--link-sm accordion__link" data-target="#accordion-tabs__accordions-<?php echo $k; ?>" data-toggle="class" data-class="show" >
								<?php echo $accordionHeader; ?></a>
								<div class="accordion__content" id="accordion-tabs__accordions-<?php echo $k; ?>">
									<div class="accordion__content__inner typography">
										<div class="content">
											<?php echo $accordionContent; ?>
										</div>
										<div class="media-wrapper">
											<img src="<?php echo esc_url($accordionImage['url']); ?>" alt="<?php echo esc_attr($accordionImage['alt']); ?>" />
										</div>
									</div>
								</div> 
							<?php } endwhile; //End the loop ?>


						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>
<!-- Services section End -->


<?php 
 $sectionTitle = get_field('section_title'); 
 $sectionshortDesc = get_field('section_short_desc'); 
 $postType = get_field('select_post_type'); 
 
 ?>

<!-- projects Start -->
<section class="module module__projects">
	<div class="container">
		<div class="module__projects--wrapper aos-init" data-aos="fade-left" data-aos-delay="100" data-aos-once="true">
			<h3><?php echo $sectionTitle;?> </h3>
			<div class="module module__project-slide visible-mobile">
				<div class="project-slider">
					<?php $args = array( 'post_type' => $postType, 'posts_per_page' => -1 ); ?>

					<?php $loop = new WP_Query( $args ); ?>
					<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

					<div class="media-wrapper">
						<div class="media-container">
							<?php the_post_thumbnail(); ?>
							<div class="overlay-content">
								<p><?php the_title();?></p>
								<a href="<?php the_permalink();?>">Go TO Project</a>
							</div>
						</div>
					</div>
					<?php endwhile; ?>

				</div>
			</div>
			<?php echo $sectionshortDesc;?>
		</div>
	</div>
	<div class="module module__project-slide hidden-mobile">
		<div class="project-slider aos-init" data-aos="fade-right" data-aos-delay="100" data-aos-once="true">

			<?php $args = array( 'post_type' => $postType, 'posts_per_page' => -1 ); ?>
			<?php //print_r($args); 
			$loop = new WP_Query( $args ); 
			 if ( $loop->have_posts() ) : ?>
					<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

					<div class="media-wrapper">
						<div class="media-container">
							<?php the_post_thumbnail(); ?>
							<div class="overlay-content">
								<p><?php the_title();?></p>
								<a href="<?php the_permalink();?>">Go TO Project</a>
							</div>
						</div>
					</div>
					<?php endwhile; endif;?>
					<?php wp_reset_postdata(); ?>

		</div>
	</div>
</section>
<!-- Projects End -->


<?php $sectionIntroTitleContent = get_field('section_intro_title_content');
 // Do something...    ?>
 
<!-- History Section Start -->
<section class="module module__history">
	<?php $background_image=get_field('background_image'); ?>
	<div class="bg-wrapper" style="background-image: url(<?php echo $background_image;?>)">
		<div class="container">
			<div class="module__history--wrapper">
				<?php if(!empty($sectionIntroTitleContent)){ ?>
				<div class="history-heading-copy aos-init" data-aos="fade-in" data-aos-delay="100" data-aos-once="true">
					<?php echo $sectionIntroTitleContent; ?>
				</div>
			     <?php } ?>
				<div class="module__history--wrapper--lists aos-init" data-aos="fade-in" data-aos-delay="100" data-aos-once="true">
					<?php

					// Check rows exists.
					if( have_rows('icon_block') ):

					    // Loop through rows.
					    while( have_rows('icon_block') ) : the_row();

					        // Load sub field value.
					        $iconCode = get_sub_field('icon_code');
					        $blockTitle = get_sub_field('block_title');
					        // Do something...

					    ?>
					<div class="history-list">
						<div class="content">
							<span class="icon">
								<img src="<?php echo esc_url($iconCode['url']); ?>" alt="<?php echo esc_attr($iconCode['alt']); ?>" />
							</span>
							<p><?php echo $blockTitle; ?></p>
						</div>
					</div>
					<?php // End loop. 
					  endwhile; endif; ?>
				</div>
			</div>
			<div class="module__membership">
				<?php $heading=get_field('heading');
				if(!empty($heading)){ ?>
				<h3><?php echo $heading;?></h3>
				<?php }?>
				<div class="module__membership--icon aos-init" data-aos="fade-in" data-aos-delay="500" data-aos-once="true">
					<?php

					// Check rows exists.
					if( have_rows('logo_block') ):

					    // Loop through rows.
					    while( have_rows('logo_block') ) : the_row();

					        // Load sub field value.
					        $logoList = get_sub_field('logo_list');

					        // Do something...

					    ?>
					<div>
						<img src="<?php echo esc_url($logoList['url']); ?>" alt="<?php echo esc_attr($logoList['alt']); ?>" />
					</div>
				<?php // End loop. 
					  endwhile; endif; ?>
				</div>
				<div class="button--wrapper aos-init" data-aos="fade-up" data-aos-delay="100" data-aos-once="true">
					<?php $cta_button=get_field('cta_button');
					$cta_button_link=get_field('cta_button_link');
					if(!empty($cta_button) || !empty($cta_button_link)){?>
					<a href="<?php echo $cta_button_link;?>" class="btn-link"><?php echo $cta_button;?></a>
					<?php }?>
				</div>
			</div>
		</div>
	</div>
	</section>
	<!-- History Section End -->



<?php 
        
$newsTitle = get_field('news_title');
$viewAll_post = get_field('view_all_post');
$allPost_url = get_field('all_post_url');  ?>

<?php $args = array( 'post_type' => 'post', 'posts_per_page' => -1 ); ?>
<?php //print_r($args); 
$loop = new WP_Query( $args ); 
?>
		

<!-- News Section Start -->
	<section class="module module__news">
		<div class="module__news--wrapper">
			<div class="container aos-init" data-aos="fade-in" data-aos-delay="100" data-aos-once="true">
				<h3 class="heading"><?php echo $newsTitle;?></h3>
				<div class="module__news--wrapper--lists">
					<?php if ( $loop->have_posts() ) : 
					 while ( $loop->have_posts() ) : $loop->the_post(); ?>

					<div class="news__list">
						<div class="media-wrapper">
							<?php the_post_thumbnail(); ?>
							<div class="overlay-content">
								<a href="<?php the_permalink();?>">View Article</a>
							</div>
						</div>
						<div class="content">
							<h4><?php the_title();?></h4>
							<?php echo wp_trim_words( get_the_content(), 40, '' ); ?>
							<a href="<?php the_permalink();?>">View Article</a>
						</div>
					</div>

				<?php endwhile; endif;?>
				<?php wp_reset_postdata(); ?>


				</div>
				<a class="btn btn-link">View All Article</a>
			</div>
		</div>
	</section>
	<!-- News section End -->


	<?php 
        
$ctaContent = get_field('cta_content');
$ctaBackground_image = get_field('cta_background_image');
  ?>

	<!-- CTA Section Start-->
	<section class="module module__cta" style="background-image:url('<?php echo $ctaBackground_image; ?>');">
		<div class="container">
			<div class="module__cta--wrapper aos-init" data-aos="fade-up" data-aos-delay="100" data-aos-once="true">
				<?php echo $ctaContent; ?>
			</div>
		</div>
	</section>
	<!-- CTA Section End -->


<?php get_footer(); ?>
