<?php /* template name: services*/ ?>
<?php 
get_header();

while ( have_posts() ) :
the_post(); ?>
<!-- Inner Hero Section Start -->
<section class="module module__inner-hero module__inner-hero--services">
	<div class="top-section">
		<div class="container">
			<div class="content-top-section-wrapper aos-init" data-aos-once="true" data-aos="fade-in">
				<?php $heading=get_field('heading');
	             if(!empty($heading)){?>
				<h1><?php echo $heading; ?></h1>
			<?php
				}?>
				<?php $content=get_field('content');
				if (!empty($content)){ ?>
				<p><?php echo $content;?></p>
			<?php }?>
			</div>
		</div>
		<div class="triangle-shape"></div>
	</div>
</section>
<div class="module__inner-hero--shape"></div>
<!-- Inner Hero Section End -->
<section class="module module__services-content">
	<div class="container">
		<?php $heading2=get_field('heading2');
		if(!empty($heading2)){?>
		<h3 class="aos-init" data-aos="fade-up" data-aos-once="true"><?php echo $heading2;?></h3>
	<?php }
			?>
		<div class="two-column-content">
			<div class="two-column-content-wrapper">
				<div class="col-left aos-init" data-aos="fade-left" data-aos-once="true">
					<?php $content2=get_field('content2');
					if(!empty($content2)){ ?>
					<p><?php echo $content2;?></p>
					<?php
					}?>
				</div>
				<div class="col-right aos-init" data-aos="fade-right" data-aos-once="true">
					<?php $content3=get_field('content3');
					if(!empty($content3)){ ?>
					<p><?php echo $content3;?></p>
					<?php 
					}?>
				</div>
			</div>
		</div>
		<div class="internal-services-links aos-init" data-aos="fade-in" data-aos-once="true">
			<div class="links-wrapper">
				<ul>
                  <?php if( have_rows('button') ){
                      while( have_rows('button') ) { 
						  the_row();
						  $text_url=get_sub_field('text_url');
						  $text=get_sub_field('text');
						  if(!empty($text_url) || !empty($text)){ ?>
					<li><a href="<?php echo $text_url;?>" class="btn-link"><?php echo $text; ?></a></li>
				<?php }
					  }
                      }?>
				</ul>
			</div>
		</div>
	</div>
</section>
<section id="galavanising" class="module module__image-copy module__image-copy--services">
	<div class="image-content-block">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-4 content-col">
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">
						<?php $heading4=get_field('heading4');
						if(!empty($heading4)){?>
						<h3><?php echo $heading4;?></h3>
						<?php }?>
						<?php $content4=get_field('content4');
						if(!empty($content4)){ ?>
						<p><?php echo $content4;?> </p>
						<?php }?>
						<?php $text_url1=get_field('text_url1');
						$text1=get_field('text1');
						if(!empty($text_url1) || !empty($text1)){ ?>
						<a href="<?php echo $text_url1;?>" class="btn btn-link"><?php echo $text1;?></a>
					<?php }?>
					</div>
				</div>
				<div class="col-md-6 col-lg-8 image-col">
					<div class="media-wrapper aos-init" data-aos="fade-left" data-aos-once="true">
						<div class="media-container">
							<?php $image=get_field('image');
							if(!empty($image)){ ?>
							<img src="<?php echo $image;?>" class="img-responsive">
							<?php }?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section id="express-deliver" class="module module__image-copy module__image-copy--reverse">
	<div class="image-content-block">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-5 content-col">
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">
						<?php $heading5=get_field('heading5');
						if(!empty($heading5)){ ?>
						<h3><?php echo $heading5;?></h3>
						<?php }?>
						<?php $content5=get_field('content5');
						if(!empty($content5)){ ?>
						<p><?php echo $content5;?></p>
						<?php }?>
						<?php $text_url2=get_field('text_url2');
						if(!empty($text_url2)){?>
						<a href="<?php $text_url2;?>" class="btn btn-link"><?php $text3=get_field('text3');if(!empty($text3)){echo $text3;}?></a>
						<?php }?>
					</div>
				</div>
				<div class="col-md-6 col-lg-7 image-col">
					<div class="media-wrapper aos-init" data-aos="fade-left" data-aos-once="true">
						<div class="media-container">
							<?php $image2=get_field('image2');
							if(!empty($image2)){?>
							<img src="<?php echo $image2;?>" class="img-responsive">
								<?php }?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section id="loading-delivery" class="module module__image-copy module__image-copy--services">
	<div class="image-content-block">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-4 content-col">
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">
						<?php $heading6=get_field('heading6');
						if(!empty($heading6)){ ?>
						<h3><?php echo $heading6;?></h3>
					    <?php }?>
					    <?php $content6=get_field('content6');
					     if(!empty($content6)){?>
						<p><?php  echo $content6;?></p>
				        <?php }?>
				        <?php $text3=get_field('text3');
				          $text_url3=get_field('$text_url3');
				         if(!empty($text3) || !empty($text_url3)){?>
						<a href="<?php echo $text_url3;?>" class="btn btn-link"><?php echo $text3;?></a>
						<?php }?>
					</div>
				</div>
				<div class="col-md-6 col-lg-8 image-col">
					<div class="media-wrapper aos-init" data-aos="fade-left" data-aos-once="true">
						<div class="media-container">
							<?php $image3=get_field('image3');
							if(!empty($image3)){ ?>
							<img src="<?php echo $image3;?>" class="img-responsive">
							<?php }?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section id="sandblasting" class="module module__image-copy module__image-copy--reverse">
	<div class="image-content-block">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-5 content-col">
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">
						<?php $heading7=get_field('heading7');
						if(!empty($heading7)){ ?>
						<h3><?php echo $heading7;?></h3>
						<?php }?>
						<?php $content7=get_field('content7');
						if(!empty($content7)){ ?>
						<p><?php echo $content7;?></p>
						<?php }?>
						<?php $text_url4=get_field('text_url4');
						      $text4=get_field('text4');
						if(!empty($text_url4) || !empty($text4)){?>
						<a href="<?php echo $text_url4;?>" class="btn btn-link"><?php echo $text4;?></a>
						<?php }?>
					</div>
				</div>
				<div class="col-md-6 col-lg-7 image-col">
					<div class="media-wrapper aos-init" data-aos="fade-left" data-aos-once="true">
						<div class="media-container">
							<?php $image4=get_field('image4');
							if(!empty($image4)){ ?>
							<img src="<?php echo $image4;?>" class="img-responsive">
							<?php }?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section id="industries" class="module module__image-copy module__image-copy--services">
	<div class="image-content-block">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-4 content-col">
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">
						<?php $heading8=get_field('heading8');
						if(!empty($heading8)){ ?>
						<h3><?php echo $heading8;?></h3>
					    <?php }?>
						<?php $content8=get_field('content8');
						if(!empty($content8)){ ?>
						<p><?php echo $content8;?></p>
					    <?php }?>
					    <?php $text5=get_field('text5');
					          $text_url5=get_field('text_url5');
					    if(!empty($text5) || empty($text_url5)){ ?>
						<a href="<?php echo $text_url5;?>" class="btn btn-link"><?php echo $text5;?></a>
					<?php }?>
					</div>
				</div>
				<div class="col-md-6 col-lg-8 image-col">
					<div class="media-wrapper aos-init" data-aos="fade-left" data-aos-once="true">
						<div class="media-container">
							<?php $image5=get_field('image5');
							if(!empty($image5)){ ?>
							<img src="<?php echo $image5;?>" class="img-responsive">
							<?php }?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<div class="triangle-shape-inverted"></div>
<?php endwhile;
get_footer();
?>