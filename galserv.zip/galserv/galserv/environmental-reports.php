<?php
/**
 * The template for displaying all pages
 * Template Name: Environmental Reports
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package galserv
 */

get_header();

while ( have_posts() ) :
the_post(); 
$contentOnLeft = get_field( "content_on_left" );
$ImageonRight = get_field( "left_image" );
$imageOnLeft = get_field( "image_on_left" );
$contentOnRight = get_field( "content_on_right" );

$yagoonaTitle=get_field('yagoona_title');
$yogonaButtonText = get_field( "yogona_button_text" );
$yogonaButtonLink=get_field('yogona_button_link');

$harbourTitleText=get_field('harbour_title_text');
$buttonText=get_field('button_text');
$buttonUrl=get_field('button_url');

?>

<!-- Inner Hero Section Start -->
<section class="module module__inner-hero">
	<div class="top-section">
		<div class="container">
			<div class="content-top-section-wrapper aos-init" data-aos-once="true" data-aos="fade-in">
				<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
				<?php the_content();?>
			</div>
		</div>
		<div class="triangle-shape"></div>
	</div>
</section>
<?php $featuredUrl = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'full' );  if(!empty($featuredUrl)){?>?>
<div class="module__inner-hero--shape" style="background-image:url(<?php echo $featuredUrl;?>);"></div>
<?php } ?>
<!-- Inner Hero Section End -->
<section class="module module__image-copy">
	<div class="image-content-block">
		<div class="container">
			<div class="row">
				<div class="col-md-6 content-col">
					<?php 	if( !empty( $contentOnLeft ) ): ?>
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">
						<?php echo $contentOnLeft; ?>
					</div>
					<?php endif; ?>
				</div>
				<div class="col-md-6 image-col">
					<div class="media-wrapper aos-init" data-aos="fade-left" data-aos-once="true">
						<?php 	if( !empty( $ImageonRight ) ): ?>
						<div class="media-container">
							<img src="<?php echo esc_url($ImageonRight['url']); ?>" alt="<?php echo esc_attr($ImageonRight['alt']); ?>" class="img-responsive" />
						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="module module__image-copy module__image-copy--reverse">
	<div class="image-content-block">
		<div class="container">
			<div class="row">
				<div class="col-md-6 content-col">
					<?php 	if( !empty( $contentOnRight ) ): ?>
					<div class="content-wrapper aos-init" data-aos="fade-right" data-aos-once="true">
						<?php echo $contentOnRight; ?>
					</div>
					<?php endif; ?>
				</div>
				<div class="col-md-6 image-col">
					<div class="media-wrapper aos-init" data-aos="fade-left" data-aos-once="true">
						<?php 	if( !empty( $imageOnLeft ) ): ?>
						<div class="media-container">
							<img src="<?php echo esc_url($imageOnLeft['url']); ?>" alt="<?php echo esc_attr($imageOnLeft['alt']); ?>" class="img-responsive" />
						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<div class="triangle-shape-inverted"></div>
<section class="module module__report bg-grey">
	<div class="container">
		<h3 class="aos-init" data-aos="fade-up" data-aos-once="true"><?php if($yagoonaTitle){ echo $yagoonaTitle;}?></h3>
		<div class="module__report--lists aos-init" data-aos="fade-up" data-aos-once="true">
			<ul>
				<?php // Check rows exists.
				if( have_rows('yagoona_list') ):
			    // Loop through rows.
			    while( have_rows('yagoona_list') ) : the_row();
			    // Load sub field value.
			    $listTitle = get_sub_field('list_title');
			    $listUrl = get_sub_field('list_url');
			    // Do something...?>
				<li>
					<span><?php echo $listTitle; ?></span>
					<a href="<?php echo $listUrl; ?>">View ></a>
				</li>
				<?php  // End loop. 
					endwhile; endif; ?>
			</ul>
			<?php 	if( !empty( $yogonaButtonLink || $yogonaButtonText ) ): ?>
			<a href="<?php echo $yogonaButtonLink; ?>" class="btn-link aos-init" data-aos="fade-up" data-aos-once="true"><?php echo $yogonaButtonText; ?></a>
			<?php endif; ?>
		</div>
	</div>
</section>
<div class="triangle-shape-inverted white-triangle"></div>
<section class="module module__report">
	<div class="container">
		<h3 class="aos-init" data-aos="fade-in" data-aos-once="true">COFFS HARBOUR</h3>
		<div class="module__report--lists aos-init" data-aos="fade-up" data-aos-once="true">
			<ul>
				<?php // Check rows exists.
				if( have_rows('coffs_harbour_list') ):
			    // Loop through rows.
			    while( have_rows('coffs_harbour_list') ) : the_row();
			    // Load sub field value.
			    $listTitle = get_sub_field('list_title');
			    $listUrl = get_sub_field('list_url');
			    // Do something...?>
				<li>
					<span><?php echo $listTitle; ?></span>
					<a href="<?php echo $listUrl; ?>">View ></a>
				</li>
				<?php  // End loop. 
					endwhile; endif; ?>
			</ul>
			<?php 	if( !empty( $buttonUrl || $buttonText ) ): ?>
			<a href="<?php echo $buttonUrl;?>" class="btn-link aos-init" data-aos="fade-up" data-aos-once="true"><?php echo $buttonText;?></a>
		<?php endif; ?>
		</div>
	</div>
</section>
<div class="bottom-skewed-div"></div>

<?php endwhile; // End of the loop. ?>
<?php
//get_sidebar();
get_footer();
