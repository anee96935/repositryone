<?php // Case: Paragraph layout.
        
            $bannerImage = get_sub_field('banner_image');
            $bannerHeadingline1 = get_sub_field('heading_line1');
            $bannerHeadingline2 = get_sub_field('heading_line2');
            $bannerHeadingline3 = get_sub_field('heading_line3');
            $bannerSub_title = get_sub_field('banner_sub_title');
            $aboutContent = get_sub_field('about_content');
            //$bannerButton = get_sub_field('banner_button');
           // $buttonLink = get_sub_field('button_link');
            // Do something...
          if(!empty($bannerImage) || !empty($bannerHeadingline1) || !empty($bannerHeadingline2) || !empty($bannerHeadingline3) || !empty($bannerSub_title) || !empty($aboutContent)){
?>
<section class="module module__hero">
	<div class="module__hero__content-bg">
		<div class="media-wrapper">
			<img src="<?php echo esc_url($bannerImage['url']); ?>" alt="<?php echo esc_attr($bannerImage['alt']); ?>" />
			<div class="overlay"></div>
		</div>
	</div>
	<div class="triangle-shape-content">
		<div class="container">
			<div class="content aos-init" data-aos="fade-in" data-aos-delay="300" data-aos-once="true">
				<div class="heading-1 heading-font heading-white"><?= $bannerHeadingline1; ?></div>
				<div class="heading-2 heading-white">
					<span class="heading-font"><?= $bannerHeadingline2; ?></span>
					<span class="normal-tex"><?= $bannerSub_title; ?></span>
				</div>
				<div class="heading-1 heading-font heading-blue"><?= $bannerHeadingline3;?></div>
			</div>
			<div class="hero__banner--content-bottom hidden-mobile aos-init" data-aos="fade-in" data-aos-delay="400" data-aos-once="true">
				<?=$aboutContent;?>
				
			</div>
		</div>
	</div>
</section>
<?php } ?>