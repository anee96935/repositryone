<?php // Case: Paragraph layout.
        
            $sectionIntroTitleContent = get_sub_field('section_intro_title_content');

            // Do something...
          
?>
<!-- History Section Start -->
<section class="module module__history">
	<?php $background_image=get_sub_field('background_image'); ?>
	<div class="bg-wrapper" style="background-image: url(<?php echo $background_image;?>)">
		<div class="container">
			<div class="module__history--wrapper">
				<?php if(!empty($sectionIntroTitleContent)){ ?>
				<div class="history-heading-copy aos-init" data-aos="fade-in" data-aos-delay="100" data-aos-once="true">
					<?php echo $sectionIntroTitleContent; ?>
				</div>
			     <?php } ?>
				<div class="module__history--wrapper--lists aos-init" data-aos="fade-in" data-aos-delay="100" data-aos-once="true">
					<?php

					// Check rows exists.
					if( have_rows('icon_block') ):

					    // Loop through rows.
					    while( have_rows('icon_block') ) : the_row();

					        // Load sub field value.
					        $iconCode = get_sub_field('icon_code');
					        $blockTitle = get_sub_field('block_title');
					        // Do something...

					    ?>
					<div class="history-list">
						<div class="content">
							<span class="icon">
								<img src="<?php echo esc_url($iconCode['url']); ?>" alt="<?php echo esc_attr($iconCode['alt']); ?>" />
							</span>
							<p><?php echo $blockTitle; ?></p>
						</div>
					</div>
					<?php // End loop. 
					  endwhile; endif; ?>
				</div>
			</div>
			<div class="module__membership">
				<?php $heading=get_sub_field('heading');
				if(!empty($heading)){ ?>
				<h3><?php echo $heading;?></h3>
				<?php }?>
				<div class="module__membership--icon aos-init" data-aos="fade-in" data-aos-delay="500" data-aos-once="true">
					<?php

					// Check rows exists.
					if( have_rows('logo_block') ):

					    // Loop through rows.
					    while( have_rows('logo_block') ) : the_row();

					        // Load sub field value.
					        $logoList = get_sub_field('logo_list');

					        // Do something...

					    ?>
					<div>
						<img src="<?php echo esc_url($logoList['url']); ?>" alt="<?php echo esc_attr($logoList['alt']); ?>" />
					</div>
				<?php // End loop. 
					  endwhile; endif; ?>
				</div>
				<div class="button--wrapper aos-init" data-aos="fade-up" data-aos-delay="100" data-aos-once="true">
					<?php $cta_button=get_sub_field('cta_button');
					$cta_button_link=get_sub_field('cta_button_link');
					if(!empty($cta_button) || !empty($cta_button_link)){?>
					<a href="<?php echo $cta_button_link;?>" class="btn-link"><?php echo $cta_button;?></a>
					<?php }?>
				</div>
			</div>
		</div>
	</div>
	</section>
	<!-- History Section End -->
