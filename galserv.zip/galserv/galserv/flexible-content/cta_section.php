<?php 
        
$ctaContent = get_sub_field('cta_content');
$ctaBackground_image = get_sub_field('cta_background_image');
  ?>

	<!-- CTA Section Start-->
	<section class="module module__cta" style="background-image:url('<?php echo $ctaBackground_image; ?>');">
		<div class="container">
			<div class="module__cta--wrapper aos-init" data-aos="fade-up" data-aos-delay="100" data-aos-once="true">
				<?php echo $ctaContent; ?>
			</div>
		</div>
	</section>
	<!-- CTA Section End -->