<?php 
        
$newsTitle = get_sub_field('news_title');
$viewAll_post = get_sub_field('view_all_post');
$allPost_url = get_sub_field('all_post_url');  ?>

<?php $args = array( 'post_type' => 'post', 'posts_per_page' => -1 ); ?>
<?php //print_r($args); 
$loop = new WP_Query( $args ); 
?>
		

<!-- News Section Start -->
	<section class="module module__news">
		<div class="module__news--wrapper">
			<div class="container aos-init" data-aos="fade-in" data-aos-delay="100" data-aos-once="true">
				<h3 class="heading"><?php echo $newsTitle;?></h3>
				<div class="module__news--wrapper--lists">
					<?php if ( $loop->have_posts() ) : 
					 while ( $loop->have_posts() ) : $loop->the_post(); ?>

					<div class="news__list">
						<div class="media-wrapper">
							<?php the_post_thumbnail(); ?>
							<div class="overlay-content">
								<a href="<?php the_permalink();?>">View Article</a>
							</div>
						</div>
						<div class="content">
							<h4><?php the_title();?></h4>
							<?php echo wp_trim_words( get_the_content(), 40, '' ); ?>
							<a href="<?php the_permalink();?>">View Article</a>
						</div>
					</div>

				<?php endwhile; endif;?>
				<?php wp_reset_postdata(); ?>


				</div>
				<a class="btn btn-link">View All Article</a>
			</div>
		</div>
	</section>
	<!-- News section End -->