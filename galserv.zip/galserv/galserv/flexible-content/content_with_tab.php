<?php 
$tabHeading = get_sub_field('tab_heading');

?>

<!-- Services section Start -->
<?php // check if the repeater field has rows of data
if( have_rows('vertical_tab_block') ): ?>


	<section class="module module__services accordion-tabs">
		<div class="container aos-init  aos-init" data-aos="fade-up" data-aos-delay="100" data-aos-once="true">
			<div class="hero__banner--content-bottom visible-mobile">
				<h3><span>About us</span> rspiciatis unde omnis iste natus</h3>
				<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem</p>
				<a href="" class="btn btn-link">Find out more</a>
			</div>
			<div class="module__services--wrapper">
				<?php if(!empty($tabHeading)){echo $tabHeading; } ?>
				
				<div class="module__services--tabs">
					<div class="accordion-tabs__container">
						<div class="accordion-tabs__tabs hidden-mobile inview-animation">
							<div class="tabs-col tabs-col--left inview-anime">

								<?php   

					 	// loop through the rows of data for the tab header
								$i = 0;
								while ( have_rows('vertical_tab_block') ) : the_row(); $i++;
									
									$accordionHeader = get_sub_field('accordion_header');?>

									<button type="button" class="btn btn--link-sm tabs__link <?php if($i==1){echo 'active';}?>" data-target="#accordion-tabs__tabs-<?php echo $i; ?>">
										<?php echo $accordionHeader; ?>
									</button>
								<?php endwhile; //End the loop ?>
							</div>
							<div class="tabs-col tabs-col--right inview-anime">
								<?php $j=0; while ( have_rows('vertical_tab_block') ) : the_row();  $j++;
								$accordionContent = get_sub_field('accordion_content');
								$accordionImage = get_sub_field('accordion_image');
								?>
								<div class="tabs__content <?php if($j==1){echo 'show';}?>" id="accordion-tabs__tabs-<?php echo $j; ?>">
									<div class="tabs__content__inner typography">
										<div class="content">
											<?php echo $accordionContent; ?>
										</div>
										<div class="media-wrapper">
											<img src="<?php echo esc_url($accordionImage['url']); ?>" alt="<?php echo esc_attr($accordionImage['alt']); ?>" />
										</div>
									</div>
									
								</div>
								<?php 
							endwhile; //End the loop ?>
						</div>
					</div>
					<div class="accordion-tabs__accordions hidden-desktop inview-animation">
						<?php $k=0; while ( have_rows('vertical_tab_block') ) : the_row();  $k++;
						$accordionHeader = get_sub_field('accordion_header');
						$accordionContent = get_sub_field('accordion_content');
						$accordionImage = get_sub_field('accordion_image'); 
						if($k==1) {
							?>
							
							<div class="accordion inview-anime">
								<a href="#" class="btn btn--link-sm accordion__link <?=$key==0 ? 'class-toggled': '';?>"
									data-target="#accordion-tabs__accordions-<?php echo $k; ?>" data-toggle="class" data-class="show" >
									<?php echo $accordionHeader; ?>
								</a>
								<div class="accordion__content show" id="accordion-tabs__accordions-<?php echo $k; ?>">
									<div class="accordion__content__inner typography">
										<div class="content">
											<?php echo $accordionContent; ?>
										</div>
										<div class="media-wrapper">
											<img src="<?php echo esc_url($accordionImage['url']); ?>" alt="<?php echo esc_attr($accordionImage['alt']); ?>" />
										</div>
									</div>
								</div>
							</div>
						<?php } else{ ?>
							
							<a href="#" class="btn btn--link-sm accordion__link" data-target="#accordion-tabs__accordions-<?php echo $k; ?>" data-toggle="class" data-class="show" >
								<?php echo $accordionHeader; ?></a>
								<div class="accordion__content" id="accordion-tabs__accordions-<?php echo $k; ?>">
									<div class="accordion__content__inner typography">
										<div class="content">
											<?php echo $accordionContent; ?>
										</div>
										<div class="media-wrapper">
											<img src="<?php echo esc_url($accordionImage['url']); ?>" alt="<?php echo esc_attr($accordionImage['alt']); ?>" />
										</div>
									</div>
								</div> 
							<?php } endwhile; //End the loop ?>


						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>
<!-- Services section End -->