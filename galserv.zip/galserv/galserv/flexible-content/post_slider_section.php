<?php 
 $sectionTitle = get_sub_field('section_title'); 
 $sectionshortDesc = get_sub_field('section_short_desc'); 
 $postType = get_sub_field('select_post_type'); 
 
 ?>

<!-- projects Start -->
<section class="module module__projects">
	<div class="container">
		<div class="module__projects--wrapper aos-init" data-aos="fade-left" data-aos-delay="100" data-aos-once="true">
			<h3><?php echo $sectionTitle;?> </h3>
			<div class="module module__project-slide visible-mobile">
				<div class="project-slider">
					<?php $args = array( 'post_type' => $postType, 'posts_per_page' => -1 ); ?>

					<?php $loop = new WP_Query( $args ); ?>
					<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

					<div class="media-wrapper">
						<div class="media-container">
							<?php the_post_thumbnail(); ?>
							<div class="overlay-content">
								<p><?php the_title();?></p>
								<a href="<?php the_permalink();?>">Go TO Project</a>
							</div>
						</div>
					</div>
					<?php endwhile; ?>

				</div>
			</div>
			<?php echo $sectionshortDesc;?>
		</div>
	</div>
	<div class="module module__project-slide hidden-mobile">
		<div class="project-slider aos-init" data-aos="fade-right" data-aos-delay="100" data-aos-once="true">

			<?php $args = array( 'post_type' => $postType, 'posts_per_page' => -1 ); ?>
			<?php //print_r($args); 
			$loop = new WP_Query( $args ); 
			 if ( $loop->have_posts() ) : ?>
					<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

					<div class="media-wrapper">
						<div class="media-container">
							<?php the_post_thumbnail(); ?>
							<div class="overlay-content">
								<p><?php the_title();?></p>
								<a href="<?php the_permalink();?>">Go TO Project</a>
							</div>
						</div>
					</div>
					<?php endwhile; endif;?>
					<?php wp_reset_postdata(); ?>

		</div>
	</div>
</section>
<!-- Projects End -->