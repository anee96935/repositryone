<?php 
if($i ==1)
{
$contet .= '<div class="media-insights-inner">
                <div class="post-item">
                    <div class="post-item-img">
                        <a class="images" href="'.get_the_permalink().'"><img class="img-responsive" src="'.$image_url1.'" alt="'.get_the_title().'"></a>
                    </div>
                    <div class="article-content">';
                        foreach(get_the_category( $post->ID ) as $term){ 
                            $term_link = get_term_link($term->term_id);
                            $contet .= '<span class="cat">
                                <a href="'.$term_link.'">'.$term->name.'</a>
                            </span>';
                        }
                        $contet .= '<h2><a class="images" href="'.get_the_permalink().'">'. get_the_title().'</a>
                        </h2>
                        <p>'.wp_trim_words( get_the_content(), 40, '...' ).'</p>
                        <span class="cnt-btn"><a href="'.get_the_permalink().'" class="custom-button" role="button">Read more</a></span>
                    </div>
                </div>
            </div>';
}
else
{
if($i ==2){$contet .= '<div class="media-insights-blogs-wrapp" id="media-insights-blogs-wrapp">';}

    $contet .= '<div class="media-insights-inner-blogs">
        <div class="post-item">
            <div class="post-item-img">
                <a class="images" href="'.get_the_permalink().'"><img class="img-responsive" src="'.$image_url.'" alt="'.get_the_title().'"></a>
            </div>
            <div class="article-content">';
                foreach(get_the_category( $post->ID ) as $term){ 
                    $term_link = get_term_link($term->term_id);
                    $contet .= '<span class="cat">
                        <a href="'.$term_link.'">'.$term->name.'</a>
                    </span>';
                }
                $contet .= '<h4><a class="images" href="'.get_the_permalink().'">'. get_the_title().'</a>
                </h4>
                <p>'.wp_trim_words( get_the_content(), 12, '...' ).'</p>
            </div>
        </div>
    </div>';
} ?>